public enum Enum {
    A,B,C,D,E,F,G,H
}

