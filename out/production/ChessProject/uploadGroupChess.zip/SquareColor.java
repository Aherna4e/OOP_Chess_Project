public enum SquareColor {
    white,brown
}
